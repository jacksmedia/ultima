-- by epigonone --

Either of these patches replaces the special Calcabrina dolls sprite with another one. The dolls now use the "girl villager" sprite. It's not a big stretch, and they're only seen once in the game.

The special new sprite is used by the cameo boss who ambushes the party right after the Mom Bomb fight, and shows up again later on.  No spoiler on who this is...