FF4Ultima_MObreckPatches.zip
by MObreck, 2022

CHANGES: World map and battle sprites for Rosa, Kydia (Kid Rydia), Rydia, Palom, Porom, and Golbez. See the readme for more details.

EFFECT: Graphics based on those in "FFIV Pixel Remaster" replace these characters' sprites on map and in battle.

-Rosa, Palom, Porom, Golbez, and both Rydia sprite replacers based off Pixel Remaster (Heavily edited to conform with the SNES version's size and palette restrictions)

-All the player sprites except Golbez should work with both Ultima AND any unheadered 1.1 version of Final Fantasy 2 SNES!
Golbez only works with Ultima due to modifying the custom playable version.
