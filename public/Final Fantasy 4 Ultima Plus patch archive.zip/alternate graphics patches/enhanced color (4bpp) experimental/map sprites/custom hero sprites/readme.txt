These need to be used AFTER one of the full NPC patches in this archive:

 - FF4UP - 4bpp Map Sprites (WS, by Gedankenschild).ips
 - FF4UP Canon Remaster v1.1 (epigonone, Gedankenschild).ips
 - FF4UP Pixel Remaster NPCs (by Anderson Viana, Gedankenschild).ips

They won't do anything without one of these base patches.