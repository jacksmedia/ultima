4bpp Gilgamesh add (by Flamepurge & xJ4cks)
------------------------------------------

This is already a part of the main "FF4UP - 4bpp Map Sprites v1.1 (WSC, by Gedankenschild).ips" work. It is included here to assist sprite hackers and anyone who wants to modify the two alternate 4bpp map sprite patches, "Canon Remaster" and "Pixel Remaster" styles.

This patch replaces the sprite of the "doll" used for Calbrina with a modified Gilgamesh sprite ported from FFV SNES and recolored to match the WonderSwan palette.

Beacuse it's using a preset palette, the only bytes changed are the 512 bytes for the sprite data at $1A3000 - $1A31FF.

---------------------
If you have questions, reach out in the Sprite-hacking thread at:
https://discord.com/channels/600408664381063191/1346954031926476911

Server invite:
https://discord.gg/PGMASbSnD9