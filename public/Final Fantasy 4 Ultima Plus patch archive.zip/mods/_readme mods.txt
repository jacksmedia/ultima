Final Fantasy 4 Ultima
Graphics Mods v2025
----------------------------
curated by xJ4cks,
created by numerous sprite artists (listed in the filenames)
----------------------------
Hello, please apply these patches directly over a copy of FF4 Ultima 
and you will change some of the graphics!

>>>> MOD TYPES:
- battle sprites
- map sprites
- portraits

These graphic mods are sometimes sourced from other versions of FF4, 
like: the Pixel Remaster (2017), FF Record Keeper (~2012+), FF4 PSP (2008),
FF4 Advance (2005), and FF4 Mobile (~2013), FF4 WonderSwan (~2003).

Sometimes they are recolored from these, and sometimes they are recolored 
from the classic SNES sprites.

Some talented spriters also redraw the images, as well as recoloring them.

Mix and match these 3 types of mods to make your ideal FF4 Ultima experience!


>>>> BONUS:
Experimental 16 color portraits AND map sprites are now available!

If you use these, please know that they have NOT been fully tested 
by the Ultima Plus Dev Team. They are the work of both Gedankenschild 
who hacked in the extra space and logic to make these enhanced graphics 
possible; epigonone, who completed some of the graphics imports from 
other versions of FFVA like Pixel Remaster and FF4 Advance.

Expect new content to be available here in the months ahead.

Enjoy, and give us feedback in FF4 Ultima Discord!

https://discord.gg/PGMASbSnD9

The #game-art channel is the best place to discuss these!